Core/Src/stm32f3xx_it.o: ../Core/Src/stm32f3xx_it.c ../Core/Inc/main.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal.h \
 ../Core/Inc/stm32f3xx_hal_conf.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_rcc.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32F3xx/Include/stm32f3xx.h \
 ../Drivers/CMSIS/Device/ST/STM32F3xx/Include/stm32f302x8.h \
 ../Drivers/CMSIS/Include/core_cm4.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Device/ST/STM32F3xx/Include/system_stm32f3xx.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_rcc_ex.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_gpio.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_gpio_ex.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_exti.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_dma.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_dma_ex.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_cortex.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_flash.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_flash_ex.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_i2c.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_i2c_ex.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pwr.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pwr_ex.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_tim.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_tim_ex.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_uart.h \
 ../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_uart_ex.h \
 ../Core/Inc/stm32f3xx_it.h
../Core/Inc/main.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal.h:
../Core/Inc/stm32f3xx_hal_conf.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_rcc.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32F3xx/Include/stm32f3xx.h:
../Drivers/CMSIS/Device/ST/STM32F3xx/Include/stm32f302x8.h:
../Drivers/CMSIS/Include/core_cm4.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Device/ST/STM32F3xx/Include/system_stm32f3xx.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_rcc_ex.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_gpio.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_gpio_ex.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_exti.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_dma.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_dma_ex.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_cortex.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_flash.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_flash_ex.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_i2c.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_i2c_ex.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pwr.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pwr_ex.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_tim.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_tim_ex.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_uart.h:
../Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_uart_ex.h:
../Core/Inc/stm32f3xx_it.h:
